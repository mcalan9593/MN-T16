package mon;

public class Memlib {

	private String total;
	private String usedm;
	private String freem;
	private String descripcion;
	
	public String toString(){
		return "total: "+total+" , usedm: "+usedm+" , freem: "+freem;
	}
	
	
	
	public String getDescripcion() {
		return descripcion;
	}



	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}



	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getUsedm() {
		return usedm;
	}
	public void setUsedm(String usedm) {
		this.usedm = usedm;
	}
	public String getFreem() {
		return freem;
	}
	public void setFreem(String freem) {
		this.freem = freem;
	}
	
	
}
