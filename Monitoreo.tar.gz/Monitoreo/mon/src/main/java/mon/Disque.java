package mon;

public class Disque {
	private String filesystem;
	private String blocks; 
	private String used;
	private String available;
	private Integer us;
	private String mounted;
	
	public String toString(){
		return "Filesystem: "+filesystem+", Blocks: "+blocks+"Used: "+used+", Available: "+available+", Us: "+us+", Mounted: "+mounted; 

	}
	public String getFilesystem() {
		return filesystem;
	}
	public void setFilesystem(String filesystem) {
		this.filesystem = filesystem;
	}
	public String getBlocks() {
		return blocks;
	}
	public void setBlocks(String blocks) {
		this.blocks = blocks;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}

	public Integer getUs() {
		return us;
	}
	public void setUs(Integer us) {
		this.us = us;
	}
	public String getMounted() {
		return mounted;
	}
	public void setMounted(String mounted) {
		this.mounted = mounted;
	}


}
