package mon;

import java.util.List;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class Hydra {
	
	private String subtitulo;
	private String titulo;
	private String hostname;
	private String capa;
	private String texto;
	private String ip;
	private List <Disque> unique;
	private JRBeanCollectionDataSource listo;
	private List <Memlib> gracon;
	private JRBeanCollectionDataSource great;
	
	


	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public List<Memlib> getGracon() {
		return gracon;
	}
	public void setGracon(List<Memlib> gracon) {
		this.gracon = gracon;
	}
	public JRBeanCollectionDataSource getGreat() {
		return great;
	}
	public void setGreat(JRBeanCollectionDataSource great) {
		this.great = great;
	}
	public List<Disque> getUnique() {
		return unique;
	}
	public void setUnique(List<Disque> unique) {
		this.unique = unique;
	}
	public JRBeanCollectionDataSource getListo() {
		return listo;
	}
	public void setListo(JRBeanCollectionDataSource listo) {
		this.listo = listo;
	}
	public String getSubtitulo() {
		return subtitulo;
	}
	public void setSubtitulo(String subtitulo) {
		this.subtitulo = subtitulo;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getCapa() {
		return capa;
	}
	public void setCapa(String capa) {
		this.capa = capa;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	
}