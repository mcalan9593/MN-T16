package mon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.jfree.ui.Size2D;

import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class Prueba {
    Date fecha=new Date();
    SimpleDateFormat formato= new SimpleDateFormat("yyyyMMdd"); 
	String fileName = "/RUTA/.jasper";
	
	HashMap hm = new HashMap();

	public Prueba() {
		super();
	}

	public void leerarchivo(String variable) {
		File archivo = null, bom;
		FileReader fr = null, zaz;
		BufferedReader br = null, zoom;

		try {
			archivo = new File("/RUTA/.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);

			String linea;
			List<Hydra> list = new ArrayList<Hydra>();
			while ((linea = br.readLine()) != null) {
				String[] arreglo = linea.split("\\|");
				
				String ip = arreglo[0];
				String subtitulo = arreglo[1];
				String titulo = arreglo[2];
				String hostname = arreglo[3];
				String usuario = arreglo[4];
				String contrasena = arreglo[5];
				String capa = arreglo[6];
				
				if(!(variable.equals(titulo) || "TODO".equals(variable))){
				continue;
			
				}   

				String texto = "/RUTA/" + hostname + ".txt";
				
				bom = new File(texto);
				zaz = new FileReader(bom);
				zoom = new BufferedReader(zaz);

				String linea2 = "", textoCompleto = "";

				Disque disque = null;
				Memlib memlib = null;
				boolean pend = false;
				List<Disque> listo = new ArrayList<Disque>();
				boolean primeralinea = true;
				boolean usoDisco = false;
				List<Memlib> great = new ArrayList<Memlib>();

				while ((linea2 = zoom.readLine()) != null) {
					textoCompleto += linea2 + "\n";
					if (primeralinea) {
						primeralinea = false;
						usoDisco = true;
					} else if (usoDisco) {

						if ("             total       used       free     shared    buffers     cached"
								.equals(linea2)) {
							usoDisco = false;
							continue;
						}

						linea2 = linea2.replaceAll(" +", " ");
						String[] ArrDisc = linea2.split(" ");


						if (ArrDisc.length == 6 && pend == false) {

							disque = new Disque();
							disque.setFilesystem(ArrDisc[0]);
							disque.setBlocks(ArrDisc[1]);
							disque.setUsed(ArrDisc[2]);
							disque.setAvailable(ArrDisc[3]);
							Integer york=Integer.parseInt(ArrDisc[4].replace("%", ""));
							disque.setUs(york);
							disque.setMounted(ArrDisc[5]);
						} else if (ArrDisc.length < 6 && pend == false) {
							disque = new Disque();
							disque.setFilesystem(ArrDisc[0]);
							pend = true;
						} else if (pend == true) { // else
							ArrDisc = linea2.split(" ");
							disque.setBlocks(ArrDisc[0]);
							disque.setUsed(ArrDisc[2]);
							disque.setAvailable(ArrDisc[3]);
							Integer york=Integer.parseInt(ArrDisc[4].replace("%", ""));
							disque.setUs(york);
							disque.setMounted(ArrDisc[5]);
							pend = false;
						} if (pend == false && usoDisco) {
							listo.add(disque);
						}
					} else {
						linea2 = linea2.replaceAll(" +", " ");
						String[] ArrMem = linea2.split(" ");


						if (ArrMem.length >= 4 && linea2.startsWith("-/+")) {
							memlib = new Memlib();
							memlib.setDescripcion(ArrMem[0] + " " + ArrMem[1]);
							memlib.setUsedm(ArrMem[2]);
							memlib.setFreem(ArrMem[3]);
							
							great.add(memlib);

						} else if (ArrMem.length >= 4) {

							memlib = new Memlib();
							memlib.setDescripcion(ArrMem[0]);
							memlib.setTotal(ArrMem[1]);
							memlib.setUsedm(ArrMem[2]);
							memlib.setFreem(ArrMem[3]);
						
							great.add(memlib);

							//
						}

					}
					
					//for(memlib elmemto : great){
						//System.out.println("$$$$$: " + elmemto.toString());
					//}
				}
				
				Hydra object = new Hydra();
				object.setCapa(capa);
				object.setHostname(hostname);
				object.setIp(ip);
				object.setSubtitulo(subtitulo);
				object.setTitulo(titulo);
				object.setTexto(textoCompleto);
				object.setUnique(listo);
				object.setGracon(great);
				if (listo!=null && !listo.isEmpty()){
					object.setListo(new JRBeanCollectionDataSource(listo));
				}else {
					object.setListo(null);
				}
				if (great!=null && !great.isEmpty()){
				object.setGreat(new JRBeanCollectionDataSource(great));
				}else {
					object.setGreat(null);
				}
				list.add(object);
			}
			
			
			try {
				String outFileNamePDF = "/RUTA/"+variable+formato.format(fecha)+".pdf";
				hm.put("achicalada", new JRBeanCollectionDataSource(list));
				// JasperReport
				// manager=JasperManager.compileReport(fileName);
				JasperPrint print = JasperFillManager.fillReport(fileName, hm, new JREmptyDataSource());
				JRExporter exporter = new net.sf.jasperreports.engine.export.JRPdfExporter();
				// parameter used for the destined file.
				exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, outFileNamePDF);
				exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
				// export to .pdf
				exporter.exportReport();
				System.out.println("Created file: " + outFileNamePDF);
				System.out.println("Done!");

			} catch (JRException e) {
				e.printStackTrace();
			}

			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != fr) {
					fr.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void main(String[] args)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		new Prueba().leerarchivo(args[0]);
	}

}
